import sqlite3
import re
import matched_medical_terms_clova as me_clova

import requests
import uuid
import time
import json


def search_terms(search_query):
    try:
        conn = sqlite3.connect('medical_terms_split.db')
        cursor = conn.cursor()
        
        # term_ko와 term_en을 가져옴
        cursor.execute("SELECT term_ko, term_en, explanation FROM terms")
        all_results = cursor.fetchall()
        
        # term_ko와 term_en과 비교하여 결과 필터링
        filtered_results = [
            (term_ko, term_en, explanation) for term_ko, term_en, explanation in all_results
            if search_query == term_ko or search_query == term_en
        ]
        
        return filtered_results

    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
        return []

    finally:
        if conn:
            conn.close()


def main():
    secret_key = 'Zk56dFRYbHlJY0JRd0xtYVFWYnV2SGpaUW1Uc0pNVno='
    api_url = 'https://pg371d7zjc.apigw.ntruss.com/custom/v1/32552/735b76b30cedecfca71465cd187dd8dab363e2a5e987f502ad9581a8738ff988/general'
    image_file = 'test22.jpg'

    # OCR 수행
    result = me_clova.perform_ocr(image_file, secret_key, api_url)
    
    for result_X in result:
        results = search_terms(result_X)
        
        if results:
            print(f"\n'{result_X}'에 대한 검색 결과:")
            for term_ko, term_en, explanation in results:
                print(f"한국어 용어: {term_ko}")
                print(f"영어 용어: {term_en}")
                print("설명:")
                print(explanation)
        
        # print()  # 빈 줄 출력

if __name__ == "__main__":
    main()