from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
import torch
from datasets import load_dataset

# 모델과 토크나이저 로드
model_name = "skt/kogpt2-base-v2"  # 한국어 GPT-2 모델
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# 데이터 로드
dataset = load_dataset('json', data_files='medical_data.json')

# 데이터 구조 확인
print(dataset['train'][0])  # 첫 번째 예시 출력

# 데이터 전처리
def preprocess_function(examples):
    inputs = [example["instruction"] + example["input"] for example in examples]
    model_inputs = tokenizer(inputs, max_length=512, truncation=True, padding="max_length")
    
    labels = tokenizer(examples["output"], max_length=512, truncation=True, padding="max_length")
    
    model_inputs["labels"] = labels["input_ids"]
    return model_inputs

tokenized_datasets = dataset.map(preprocess_function, batched=True)

# 학습 설정
training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=3,
    per_device_train_batch_size=4,
    save_steps=10_000,
    save_total_limit=2,
)

# 트레이너 초기화 및 학습
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_datasets["train"],
)

trainer.train()

# 챗봇 함수 정의
def generate_response(prompt):
    inputs = tokenizer(prompt, return_tensors="pt")
    outputs = model.generate(**inputs, max_length=512, num_return_sequences=1)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

def chatbot():
    print("의학 용어 챗봇입니다. 질문을 입력하세요. (종료하려면 'quit' 입력)")
    while True:
        user_input = input("사용자: ")
        if user_input.lower() == 'quit':
            break
        response = generate_response(user_input)
        print("챗봇:", response)

# 챗봇 실행
chatbot()