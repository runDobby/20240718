import sqlite3
import json

def prepare_data(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT term, explanation FROM terms")
    data = cursor.fetchall()
    
    formatted_data = []
    for term, explanation in data:
        formatted_data.append({
            "instruction": f"다음 의학 용어에 대해 설명해주세요: {term}",
            "input": "",
            "output": explanation
        })
    
    conn.close()
    
    with open('medical_data.json', 'w', encoding='utf-8') as f:
        json.dump(formatted_data, f, ensure_ascii=False, indent=2)

prepare_data('medical_terms2.db')