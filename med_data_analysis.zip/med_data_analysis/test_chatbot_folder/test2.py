# from transformers import AutoTokenizer, AutoModelForCausalLM

# model_name = "path_to_llama_3_model"
# tokenizer = AutoTokenizer.from_pretrained(model_name)
# model = AutoModelForCausalLM.from_pretrained(model_name)


# Load model directly
from transformers import AutoTokenizer, AutoModelForCausalLM

# model_name = "path_to_llama_3_model"
# tokenizer = AutoTokenizer.from_pretrained("meta-llama/Meta-Llama-3-8B")
# model = AutoModelForCausalLM.from_pretrained("meta-llama/Meta-Llama-3-8B")


model_name = "skt/kogpt2-base-v2"  # 한국어 GPT-2 모델
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)