import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

# CUDA GPU 사용 가능 여부 확인
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# 모델과 토크나이저 로드
model = AutoModelForCausalLM.from_pretrained("yanolja/EEVE-Korean-Instruct-10.8B-v1.0")
tokenizer = AutoTokenizer.from_pretrained("yanolja/EEVE-Korean-Instruct-10.8B-v1.0")

# 모델을 GPU로 이동
model = model.to(device)

prompt_template = "A chat between a curious user and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the user's questions.\nHuman: {prompt}\nAssistant:\n"
text = '한국의 수도는 어디인가요? 아래 선택지 중 골라주세요.\n\n(A) 경성\n(B) 부산\n(C) 평양\n(D) 서울\n(E) 전주'
model_inputs = tokenizer(prompt_template.format(prompt=text), return_tensors='pt')

# 입력을 GPU로 이동
model_inputs = {k: v.to(device) for k, v in model_inputs.items()}

outputs = model.generate(**model_inputs, max_new_tokens=256)

# 출력을 CPU로 이동하여 디코딩
output_text = tokenizer.batch_decode(outputs.cpu(), skip_special_tokens=True)[0]
print(output_text)