import requests
from bs4 import BeautifulSoup

while url != None:
    
    # 웹페이지 URL
    url = "https://www.amc.seoul.kr/asan/healthinfo/easymediterm/easyMediTermList.do?pageIndex=1&searchKeyword="

    # 웹페이지 가져오기
    response = requests.get(url)

    # BeautifulSoup 객체 생성
    soup = BeautifulSoup(response.text, 'html.parser')

    # #listForm > div > table > tbody 선택
    target_element = soup.select_one("#listForm > div > table > tbody")

    if target_element:
        # tbody 내의 모든 tr 요소 찾기
        rows = target_element.find_all('tr')
        
        for row in rows:
            # 각 행에서 td 요소들 찾기
            cols = row.find_all('td')
            if cols:
                # 의학용어
                term = cols[1].text.strip()
                print(term)
    else:
        print("요소를 찾을 수 없습니다.")