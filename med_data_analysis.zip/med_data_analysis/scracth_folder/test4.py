import requests
from bs4 import BeautifulSoup
import sqlite3
import time

# SQLite 데이터베이스 연결
conn = sqlite3.connect('medical_terms2.db')
cursor = conn.cursor()

# 테이블 생성
cursor.execute('''
CREATE TABLE IF NOT EXISTS terms
(id INTEGER PRIMARY KEY, number INTEGER, term TEXT, explanation TEXT)
''')

# 기본 URL
base_url = "https://www.amc.seoul.kr/asan/healthinfo/easymediterm/easyMediTermDetail.do"

# 페이지 1부터 5016까지 순회
for page in range(1, 5017):
    url = f"{base_url}?dictId={page}"
    
    # 웹페이지 가져오기
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # #listForm > div > table > tbody 선택
    target_element = soup.select_one("#popupWrap > div.popHeader > h1")
    explaination_element = soup.select_one("#popupWrap > div.drugContent > div.description > dl > dd")
    
    if target_element:
        # tbody 내의 모든 tr 요소 찾기
        rows = target_element.find_all('tr')
        rows2 = explaination_element.find_all('tr')
        
        for row in rows:
            # 각 행에서 td 요소들 찾기
            cols = row.find_all('td')
            if len(cols) >= 2:  # 최소한 번호와 용어는 있어야 함
                number = cols[0].text.strip()
                term = cols[1].text.strip()
                explanation = cols[2].text.strip() if len(cols) > 2 else ""
                
                # 데이터베이스에 삽입
                cursor.execute('''
                INSERT INTO terms (number, term, explanation) 
                VALUES (?, ?, ?)
                ''', (number, term, explanation))
    
    print(f"Page {page} processed.")
    
    # 서버에 과도한 부하를 주지 않기 위해 잠시 대기
    time.sleep(1)
    
    # 50페이지마다 변경사항 저장
    if page % 50 == 0:
        conn.commit()
        print(f"Data saved up to page {page}")

# 마지막 변경사항 저장
conn.commit()

# 연결 종료
conn.close()

print("Scraping completed and data saved to SQLite database.")