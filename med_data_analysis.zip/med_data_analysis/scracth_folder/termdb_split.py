import sqlite3
import re

def split_term(term):
    # 기본 패턴: 한글(영어) 또는 한글(영어1)(영어2) 형식
    pattern = r'^(.*?)\s*\(([^()]+(?:\s*\([^()]+\))?)\)$'
    match = re.match(pattern, term)
    
    if match:
        term_ko, term_en = match.groups()
        return term_ko.strip(), term_en.strip()
    else:
        # 매치되지 않으면 전체를 한글 term으로 간주
        return term.strip(), None

def split_and_save_terms(source_db, target_db):
    source_conn = sqlite3.connect(source_db)
    source_cursor = source_conn.cursor()

    target_conn = sqlite3.connect(target_db)
    target_cursor = target_conn.cursor()

    try:
        target_cursor.execute('''CREATE TABLE IF NOT EXISTS terms
                                 (id INTEGER PRIMARY KEY,
                                  original_term TEXT,
                                  term_ko TEXT,
                                  term_en TEXT,
                                  explanation TEXT)''')

        source_cursor.execute("SELECT id, term, explanation FROM terms")
        terms = source_cursor.fetchall()

        for id, term, explanation in terms:
            term_ko, term_en = split_term(term)

            target_cursor.execute('''INSERT INTO terms (id, original_term, term_ko, term_en, explanation)
                                     VALUES (?, ?, ?, ?, ?)''',
                                  (id, term, term_ko, term_en, explanation))

        target_conn.commit()
        print(f"Terms have been successfully split and saved to {target_db}")

    except sqlite3.Error as e:
        print(f"An error occurred: {e}")

    finally:
        source_conn.close()
        target_conn.close()

# 실행
source_db = 'medical_terms2.db'
target_db = 'medical_terms_split.db'

split_and_save_terms(source_db, target_db)