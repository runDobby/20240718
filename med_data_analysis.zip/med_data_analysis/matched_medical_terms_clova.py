import requests
import uuid
import time
import json

def perform_ocr(image_file, secret_key, api_url):
    # 요청 JSON 데이터 생성
    request_json = {
        'images': [
            {
                'format': 'jpg',
                'name': 'demo'
            }
        ],
        'requestId': str(uuid.uuid4()),
        'version': 'V2',
        'timestamp': int(round(time.time() * 1000))
    }

    # 헤더 설정
    headers = {
      'X-OCR-SECRET': secret_key
    }

    # 파일 및 데이터 준비
    files = {
      'file': ('example.jpg', open(image_file,'rb'), 'image/jpeg'),
      'message': (None, json.dumps(request_json), 'application/json')
    }

    # POST 요청 보내기
    response = requests.post(api_url, headers=headers, files=files)

    # 결과를 저장할 리스트 초기화
    extracted_text_list = []

    # 결과 확인 및 텍스트 추출
    if response.status_code == 200:
        result = response.json()
        for image in result['images']:
            extracted_text_list.append(f"Image: {image['name']}")
            for field in image['fields']:
                extracted_text_list.append(field['inferText'])
    else:
        extracted_text_list.append(f"Error occurred: {response.status_code}, {response.text}")

    return extracted_text_list

# 함수 사용 예시
if __name__ == "__main__":
    # Naver Cloud에서 발급받은 secret_key
    secret_key = 'Zk56dFRYbHlJY0JRd0xtYVFWYnV2SGpaUW1Uc0pNVno='

    # API URL
    api_url = 'https://pg371d7zjc.apigw.ntruss.com/custom/v1/32552/735b76b30cedecfca71465cd187dd8dab363e2a5e987f502ad9581a8738ff988/general'

    # OCR을 수행할 이미지 파일
    image_file = 'file.jpg'

    # OCR 수행
    result = perform_ocr(image_file, secret_key, api_url)

    # 결과 확인 (옵션)
    print(result)