
# STEP 1. import modules
import cv2
import sys
import numpy as np
import insightface
from insightface.app import FaceAnalysis
from insightface.data import get_image as ins_get_image
assert insightface.__version__>='0.3'
# STEP 2. create inference instance
app = FaceAnalysis()
app.prepare(ctx_id=0, det_size=(640,640))


# STEP 3. load infence data
img1 = cv2.imread('gangdong.jpg')
img2 = cv2.imread('iu.jpg')
img3 = cv2.imread('wonbin.jpg')

img0 = cv2.imread('iuex.jpg')

# STEP 4. inference
faces1 = app.get(img1)
assert len(faces1)==1

faces2 = app.get(img2)
assert len(faces2)==1

faces3 = app.get(img3)
assert len(faces3)==1


faces0 = app.get(img0)
assert len(faces0)==1

# # STEP 5. post processing
# rimg = app.draw_on(img, faces)
# cv2.imwrite("./t1_output.jpg", rimg)
# # # then print all-to-all face similarity


face1_feat = np.array(faces1[0].normed_embedding, dtype=np.float32)
face2_feat = np.array(faces2[0].normed_embedding, dtype=np.float32)
face3_feat = np.array(faces3[0].normed_embedding, dtype=np.float32)

face0_feat = np.array(faces0[0].normed_embedding, dtype=np.float32)



aaa=[face1_feat, face2_feat, face3_feat]

print(aaa[0])



while True:

    sim1 = np.dot(face0_feat, aaa[0].T)
    print(sim1)
    
    if sim1>0.5:
        print('강동원')
        break
    

    sims2 = np.dot(face0_feat, aaa[1].T)
    print(sims2)
    
    
    if sims2>0.5:
        print('아이유')
        break


    sims3 = np.dot(face0_feat, aaa[3].T)
    print(sims3)
    
    
    if sims3>0.5:
        print('원빈')
        break
    
    
    print('자료에 없습니다')
    break



# feats = []
# for face in faces:
#     feats.append(face.normed_embedding)
# feats = np.array(feats, dtype=np.float32)
# sims = np.dot(feats, feats.T)
# print(sims)