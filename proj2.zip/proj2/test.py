import numpy as np

a=[1,2,3,4]
b=np.array(a)
print(type(b))